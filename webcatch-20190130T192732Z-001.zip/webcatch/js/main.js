$(".add-web").click(function(){
    $(".upload").slideToggle(500);
})